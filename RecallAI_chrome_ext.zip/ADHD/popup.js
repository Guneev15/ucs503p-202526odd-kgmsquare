function msToReadable(ms) {
  const totalSec = Math.floor(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  return `${h}h ${m}m`;
}

chrome.storage.local.get('browsingData', ({ browsingData }) => {
  const list = document.getElementById('list');
  list.innerHTML = '';

  if (!browsingData || Object.keys(browsingData).length === 0) {
    list.innerHTML = '<li>No data yet.</li>';
    return;
  }

  Object.entries(browsingData).forEach(([domain, ms]) => {
    const li = document.createElement('li');
    li.textContent = `${domain}: ${msToReadable(ms)}`;
    list.appendChild(li);
  });
});


