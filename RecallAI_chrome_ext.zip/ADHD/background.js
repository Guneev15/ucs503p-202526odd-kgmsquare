let activeTabId = null;
let activeDomain = null;
let lastActiveTime = Date.now();
let browsingData = {};

function getDomain(url) {
  try {
    return new URL(url).hostname.replace('www.', '');
  } catch (e) {
    return null;
  }
}

function updateTime() {
  if (!activeDomain) return;
  const now = Date.now();
  const timeSpent = now - lastActiveTime;
  
  console.log(`Updating time for ${activeDomain}: +${timeSpent} ms`);

  browsingData[activeDomain] = (browsingData[activeDomain] || 0) + timeSpent;
  lastActiveTime = now;

  chrome.storage.local.set({ browsingData }, () => {
    console.log('Browsing data saved:', browsingData);
  });
}

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  updateTime();
  activeTabId = activeInfo.tabId;
  const tab = await chrome.tabs.get(activeTabId);
  activeDomain = getDomain(tab.url);
  lastActiveTime = Date.now();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tabId === activeTabId && changeInfo.url) {
    updateTime();
    activeDomain = getDomain(changeInfo.url);
    lastActiveTime = Date.now();
  }
});

chrome.windows.onFocusChanged.addListener((windowId) => {
  updateTime();
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    activeDomain = null;
  } else {
    lastActiveTime = Date.now();
  }
});
async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    activeTabId = tab.id;
    activeDomain = getDomain(tab.url);
    lastActiveTime = Date.now();
  }
}
init();
chrome.storage.local.set({ browsingData }, () => {
  console.log('Browsing data saved:', browsingData);
});